from query import *
from database import *
#import sys
#sys.path.insert(0, '../parser')
#from parser import sentence_parse

#from nltk import stanford
#from nltk.parse.stanford import StanfordDependencyParser
import syn_calc
#import sentence_parse
if __name__ == "__main__":
    print("Program begin")
    db = Database()
    db.import_data("data.csv")
    #print(db.students[1])
    #print(db.numstudents)

    # create UI here, get first input
    #userInput = ui.get_input()
    userInput = "From those who failed exam 1, what is the lowest score for exam 2?"
    while userInput not in ["exit", "Exit", "quit", "Quit"]:
        print('User Input: ',userInput)

        originalQuestion = userInput
        processedQuestion = syn_calc.pre_process_question(originalQuestion)
        print('Pre-processing: ', processedQuestion)
        splitSentences = syn_calc.is_complex(processedQuestion)
        print('Split Sentences: ', splitSentences)

        #extract info here
        if len(splitSentences) > 1:
            calc = syn_calc.extract_calc(splitSentences[0])
            cond = syn_calc.extract_condition(splitSentences[1])
            print('Calculation parameters: ', calc)
            print('Condition parameters: ', cond)
        else:
            calc = syn_calc.extract_calc(splitSentences[0])
            cond = syn_calc.extract_condition(splitSentences[0])
            print('Calculation parameters: ', calc)
            print('Condition parameters: ', cond)
        
        q = Query()
        if cond in ['error', 'Error']: q.condition = None
        else: q.condition = Condition(cond[0], cond[1])
        q.calculation = calc
        try:
            disp_par = calc[2]
        except:
            disp_par = []
        q.expectedResult = ['scalar', disp_par]

        result = db.process_query(q)
        print('Result: ', result)
        #if len(result) == 0:
            #pass
            #ui.output_result("No student matches selection criteria")
        #else:
            #pass
            #ui.output_result(result)

        #get new input
        #userInput = ui.get_input()
        userInput = "exit"

    print("\n\nProgram exit")
